package com.facephi.example.android.widget.remote;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.facephi.FPhiWidgetAndroid.databinding.ActivityMainBinding;
import com.facephi.fphiwidgetcore.FPhiImage;
import com.facephi.fphiwidgetcore.WidgetConfiguration;
import com.facephi.fphiwidgetcore.WidgetLivenessMode;
import com.facephi.fphiwidgetcore.WidgetResult;
import com.facephi.selphi.Widget;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {
    private static final int SELPHI_WIDGET_REQUEST_CODE = 1;
    private static final String SELPHI_WIDGET_TAG = "SELPHI_WIDGET";

    private ActivityMainBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        binding.captureButton.setOnClickListener(new CaptureOnCLick());
        binding.finishButon.setOnClickListener(new FinishOnCLick());
        View view = binding.getRoot();
        setContentView(view);
    }

    private class CaptureOnCLick implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            WidgetConfiguration conf = new WidgetConfiguration();

            conf.setLivenessMode(WidgetLivenessMode.LIVENESS_PASSIVE);
            // TODO IMPORTANT!! You need to change the resourcesPath file to the proper one before running this example
            conf.setResourcesPath("fphi-selphi-widget-resources-selphi-live-1.2.zip");
            // Remove title bar when launching the widget.
            conf.setFullscreen(true);
            // This configuration lets you receive widget events on your application as they occur.
            conf.setIFPhiWidgetEventListener_classname("com.facephi.example.android.widget.remote.FPhiWidgetEventListener");

            Intent intent = new Intent(MainActivity.this, Widget.class);
            intent.putExtra("configuration", conf);
            startActivityForResult(intent, SELPHI_WIDGET_REQUEST_CODE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SELPHI_WIDGET_REQUEST_CODE) getResultFromWidget(resultCode, data);
    }

    private void getResultFromWidget(int resultCode, Intent data) {
        if (data == null) return;

        WidgetResult result = data.getParcelableExtra("result");
        if (result == null) {
            Log.d(SELPHI_WIDGET_TAG, "widget result is null");
            return;
        }

        if (resultCode == RESULT_CANCELED) {
            if (result.getException() != null) {
                if (result.getException().getExceptionType() != null) {
                    switch (result.getException().getExceptionType()) {
                        case StoppedManually:
                            Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by user");
                            break;
                        case Timeout:
                            Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by timeout");
                            break;
                        case CameraPermissionDenied:
                            Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by lack of camera permission");
                            break;
                        case SettingsPermissionDenied:
                            Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by lack of settings permission");
                            break;
                        default:
                            Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by an unexpected error");
                    }
                    return;
                }
            } else {
                Log.d(SELPHI_WIDGET_TAG, "selphi widget finished by an unexpected error");
                return;
            }
        }

        FPhiImage bestImage = result.getBestImage();

        // This step is optional. In case you need to send this image to SelphID SDK this is what you need to do:
        Bitmap bestImg = result.getBestImage().getImage();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bestImg.compress(Bitmap.CompressFormat.JPEG, 95, stream);
        byte[] byteArray = stream.toByteArray();
        String base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP);
        // base64 var holds the data you need to transmit to SelphID SDK

        applyResultFromWidget(bestImage);
    }

    private void applyResultFromWidget(FPhiImage bestImage) {
        binding.photoImageView.setImageBitmap(bestImage.getImage());
        binding.body.setVisibility(View.VISIBLE);
        binding.captureButton.setVisibility(View.INVISIBLE);
        binding.finishButon.setVisibility(View.VISIBLE);
    }

    private class FinishOnCLick implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            finish();
        }
    }
}
