FACEPHI FACE RECOGNITION TECHNOLOGY
====================================

--------------------------------------
- ANDROID STUDIO Programming Example -
--------------------------------------

In order to start with Android sample it's mandatory to have the following elements:
	Projects:
		- FPhi.Selphi.Widget.ClientExample: 
			Path: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/examples
			Description: Project containing the FacePhi User Control Programming Examples classes and resources.

	AAR Library:
		- fphi-core-widget-android:
			Path: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/lib
			Description: Android Library containing the FacePhi Widget classes and resources. This aar contains all the common native code and mathematics libraries.

		- fphi-selphi-widget-android:
			Path: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/lib
			Description: Android Library containing the Selphi Widget specific classes and resources.
			

Important: How to install Facephi Programming Examples using Android Studio:
	- Open "Android Studio"
	- Select "Open an existing Android Studio project"
	- Select the "Android Studio Programming Examples" folder:
		Default: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/examples/FPhi.Selphi.Widget.ClientExample"
	- Go to File -> Project Structure...
	- 'Add New Module (+ icon)' and Select 'Import .JAR/.AAR' Package:
		- Default: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/lib/fphi-core-widget-android.aar
		- Go to "Dependencies" Tag and add new module dependency (+ icon). Select fphi-core-widget-android project. 
	- 'Add New Module (+ icon)' and Select 'Import .JAR/.AAR' Package:
		- Default: <PATH_TO_YOUR_PACKAGE_DIRECTORY>/lib/fphi-selphi-widget-android.aar
		- Go to "Dependencies" Tag and add new module dependency (+ icon). Select fphi-selphi-widget-android project. 
	
Additionally, you’ll need to get the resources bundle zip:
	- Go to <PATH_TO_YOUR_PACKAGE_DIRECTORY>/libs to get the zip file named 'fphi-widget-resources-SelphiLive-X.X.zip'
	- Create the "assets" folder at <PATH_TO_YOUR_PACKAGE_DIRECTORY>/examples/FPhi.Selphi.Widget.ClientExample/SelphiClientExample/src/main.
	- Place the zip file named 'fphi-widget-resources-SelphiLive-X.X.zip' in it. Be sure that in Android Studio the assets folder appears in the project window and the zip file is in it.
	
Now you can compile and run/debug the project
	
	
		
Copyright 2021 FACEPHI. All rights reserved.
