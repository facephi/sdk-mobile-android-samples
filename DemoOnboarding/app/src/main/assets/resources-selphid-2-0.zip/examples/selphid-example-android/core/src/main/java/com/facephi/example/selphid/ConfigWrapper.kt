package com.facephi.example.selphid

object ConfigWrapper {
    // Add the content of the license.lic file in this variable, as a string.
    const val LICENSE = ""

    // Change to your country code to improve scan speed
    const val COUNTRY_ISO_ALPHA_2_CODE = "ES"
}
