package com.facephi.example.selphid

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDConfiguration
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDResult
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDScanMode
import com.facephi.selphid.Widget
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.*

class MainActivity : AppCompatActivity() {

    companion object {
        private const val RESULT_CODE = 1
    }

    private val frontImageView by lazy<ImageView> { findViewById(R.id.frontImageView) }
    private val backImageView by lazy<ImageView> { findViewById(R.id.backImageView) }
    private val faceImageView by lazy<ImageView> { findViewById(R.id.faceImageView) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<FloatingActionButton>(R.id.captureButton).setOnClickListener { capture() }
    }

    private fun capture() {
        // Create Widget configuration
        val widgetConfiguration = WidgetSelphIDConfiguration()
        // Add the license
        widgetConfiguration.license = ConfigWrapper.LICENSE
        // Set the resource file name in assets folder
        widgetConfiguration.resourcesPath = "fphi-selphid-widget-resources-selphid-1.0.zip"
        // Enable image return and wizard mode
        widgetConfiguration.enableImages(true)
        widgetConfiguration.wizardMode = true
        // To obtain data in a more accurate way enter the locale in the specificData property
        widgetConfiguration.scanMode = WidgetSelphIDScanMode.SMSearch
        widgetConfiguration.specificData = "${ConfigWrapper.COUNTRY_ISO_ALPHA_2_CODE}|<ALL>"

        // Launch the Widget adding widget configuration
        val intent = Intent(this, Widget::class.java)
        intent.putExtra("configuration", widgetConfiguration)
        startActivityForResult(intent, RESULT_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode != RESULT_CODE) return

        // Get the widget result from intent data
        val widgetResult = data?.getParcelableExtra<WidgetSelphIDResult>("result") ?: return

        // Read the front image from widget result
        val frontBitmap = widgetResult.documentFrontImage
        frontBitmap?.let { frontImageView.setImageBitmap(it) }

        // Read the back image from widget result
        val backBitmap = widgetResult.documentBackImage
        backBitmap?.let { backImageView.setImageBitmap(it) }

        // Read the face image from widget result
        val faceBitmap = widgetResult.faceImage
        faceBitmap?.let { faceImageView.setImageBitmap(it) }

        // Render OCR data in Log
        widgetResult.ocrResults?.let { readOcrData(it) }
    }

    private fun readOcrData(ocrResults: HashMap<String, String?>) {
        ocrResults.forEach { (key, value) ->
            value?.let { Log.d(key, it) }
        }
    }
}
