# SelphID Sample

## Requirements
In order to start with Android SelphID sample it's mandatory to have the following elements:

 - **Sample Project**
	- `selphid-example-android` located in `/examples`
	
- **SelphID Libraries**
	- `fphi-selphid-core-android-X.X.X.aar`
	- `fphi-selphid-drawer-android-X.X.X.aar`
	- `fphi-selphid-extractor-X.X.X.aar`
	
	These libraries are located in `/lib`
	
- **SelphID Resources**
	-  `fphi-selphid-widget-resources-selphid-X.X.X.zip`
	
	These resources are located in  `/lib`

- **License**
	- Valid `license.lic` file provided by FacePhi

## Project configuration
1. Copy `fphi-selphid-core-android-X.X.X.aar`, `fphi-selphid-drawer-android-X.X.X.aar` and `fphi-selphid-extractor-X.X.X.aar` in `selphid-example-android/core/libs` folder.
 
2. Copy `fphi-selphid-widget-resources-selphid-X.X.X.zip` in `selphid-example-android/core/src/main/assets`
 
3. Copy the content of the `license.lic` file into `ConfigWrapper` class located in `selphid-example-android/core/src/main/java/com/facephi/example/selphid` as a `String`
	 
	``` kotlin
	object ConfigWrapper {  
	      // Add the content of the license.lic file in this variable, as a string.  
		  const val LICENSE = "{\n" +  
		            "    \"customer\": \"FacePhi Developer\",\n" +  
		            "    \"documentType\": \"LicenseEnvelope\",\n" +  
		            "    \"license\": {\n" +  
		            "        \"comments\": \"Programing examples\",\n" +  
		            "        \"dateEnd\": \"XXXX-XX-XX\",\n" +  
		            "         \"extraData\": \"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\",\n" +  
		            "         \"licenseDocument\": true,\n" +  
		            "         \"licenseFacial\": false,\n" +  
		            "         \"licenseTokenDocument\": true,\n" +  
		            "         \"logging\": false,\n" +  
		            "         \"os\": \"Android\",\n" +  
		            "         \"packageName\": \"com.facephi.selphid.android.clientexmple\",\n" +  
		            "         \"product\": \"SelphID\",\n" +  
		            "         \"version\": \"1.0\"\n" +  
		            "    },\n" +  
		            "    \"provider\": \"FacePhi\"\n" +  
		            "}"  
	...
	```
	To correct license string escaping try to copy it using [Android Studio](https://developer.android.com/studio)
	
## Project run

1. Open project on [Android Studio](https://developer.android.com/studio)
2. Select `java_example` or `kotlin_example` in run configurations dropdown

    ![Select run configuration](doc_assets/run_config_dropdown.png)

3. Select target

    ![Select target](doc_assets/target_selector.png)

4. Click on run button

    ![Run button](doc_assets/run_button.png)
    
    
## Extra configuration

To improve the scan speed you can set the ID country issuer in widget configuration. To do this change the country [ISO 3166-1 alpha-2](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2#Officially_assigned_code_elements) code in `ConfigWrapper` class located in `selphid-example-android/core/src/main/java/com/facephi/example/selphid`.

``` kotlin  
object ConfigWrapper {    
	...  
	
	// Change to your country code to improve scan speed  
	const val COUNTRY_ISO_ALPHA_2_CODE = "ES"
}
```


Copyright 2021 FACEPHI. All rights reserved.
