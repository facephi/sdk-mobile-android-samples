package com.facephi.example.selphid;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.facephi.fphiselphidwidgetcore.WidgetSelphIDConfiguration;
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDDocumentType;
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDResult;
import com.facephi.fphiselphidwidgetcore.WidgetSelphIDScanMode;
import com.facephi.selphid.Widget;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private final int RESULT_CODE = 1;

    private ImageView frontImageView;
    private ImageView backImageView;
    private ImageView faceImageView;

    private Spinner letter1;
    private Spinner letter2;

    private Spinner docType;

    private TextView ocrText;

    ArrayList<String> letters = new ArrayList<>();
    ArrayList<String> docTypes = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frontImageView = findViewById(R.id.frontImageView);
        backImageView = findViewById(R.id.backImageView);
        faceImageView = findViewById(R.id.faceImageView);

        letter1 = findViewById(R.id.letter1);
        letter2 = findViewById(R.id.letter2);
        docType = findViewById(R.id.docType);

        ocrText = findViewById(R.id.ocrText);

        fillLetters();
        fillDocTypes();

        final ArrayAdapter<String> spinnerArrayAdapterLetter1 = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, letters);
        spinnerArrayAdapterLetter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        letter1.setAdapter(spinnerArrayAdapterLetter1);

        final ArrayAdapter<String> spinnerArrayAdapterLetter2 = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, letters);
        spinnerArrayAdapterLetter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        letter2.setAdapter(spinnerArrayAdapterLetter2);

        final ArrayAdapter<String> spinnerArrayAdapterDocTypes = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, docTypes);
        spinnerArrayAdapterDocTypes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        docType.setAdapter(spinnerArrayAdapterDocTypes);


        FloatingActionButton captureButton = findViewById(R.id.captureButton);
        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearUI();

                capture();
            }
        });
    }

    private void clearUI() {
        frontImageView.setImageBitmap(null);
        backImageView.setImageBitmap(null);
        faceImageView.setImageBitmap(null);
        ocrText.setText("");
    }

    private void fillLetters() {
        for (int i='A'; i<='Z'; i++) {
            letters.add(""+(char)i);
        }
    }
    private void fillDocTypes() {
        for (int i = 0; i< WidgetSelphIDDocumentType.values().length; i++) {
            docTypes.add(i, WidgetSelphIDDocumentType.values()[i].name());
        }
    }

    private String getCountry2() {
        return letter1.getSelectedItem().toString() + letter2.getSelectedItem().toString();
    }
    private WidgetSelphIDDocumentType getDocumentType() {
        return WidgetSelphIDDocumentType.setValue(docType.getSelectedItem().toString());
    }

    private void capture() {
        // Create Widget configuration
        WidgetSelphIDConfiguration widgetConfiguration = new WidgetSelphIDConfiguration();
        // Add the license from ConfigWrapper
        widgetConfiguration.setLicense(ConfigWrapper.LICENSE);
        // Set the resource file name in assets folder
        widgetConfiguration.setResourcesPath("fphi-selphid-widget-resources-selphid-1.0.zip");
        // Enable image return and wizard mode
        widgetConfiguration.enableImages(true);
        widgetConfiguration.setWizardMode(true);
        widgetConfiguration.setShowAfterCapture(true);
        // To obtain data in a more accurate way enter the locale in the specificData property
        widgetConfiguration.setScanMode(WidgetSelphIDScanMode.SMSearch);
        //widgetConfiguration.setSpecificData(ConfigWrapper.COUNTRY_ISO_ALPHA_2_CODE + "|<ALL>");

        widgetConfiguration.setSpecificData(getCountry2()+"|<ALL>");
        widgetConfiguration.setDocumentType(getDocumentType());

        widgetConfiguration.setTokenImageQuality(0.85f);

        // Launch the Widget adding widget configuration
        Intent intent = new Intent(this, Widget.class);
        intent.putExtra("configuration", widgetConfiguration);
        startActivityForResult(intent, RESULT_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != RESULT_CODE) return;

        // Get the widget result from intent data
        WidgetSelphIDResult widgetResult = data.getParcelableExtra("result");
        if (widgetResult == null) return;

        // Read the front image from widget result
        Bitmap frontBitmap = widgetResult.getDocumentFrontImage();
        if (frontBitmap != null) {
            frontImageView.setImageBitmap(frontBitmap);
        }

        // Read the back image from widget result
        Bitmap backBitmap = widgetResult.getDocumentBackImage();
        if (backBitmap != null) {
            backImageView.setImageBitmap(backBitmap);
        }

        // Read the face image from widget result
        Bitmap faceBitmap = widgetResult.getFaceImage();
        if (faceBitmap != null) {
            faceImageView.setImageBitmap(faceBitmap);
        }

        // Render OCR data in Log
        readOcrData(widgetResult.ocrResults);
    }

    private void readOcrData(HashMap<String, String> ocrResults) {
        if (ocrResults == null) return;

        for (String key : ocrResults.keySet()) {
            if (key.split("/").length != 1) continue;
            String value = ocrResults.get(key);
            if (value != null) Log.d(key, value);
            ocrText.append(key);
            ocrText.append(": '");
            if (value != null) ocrText.append(value); else ocrText.append("---");
            ocrText.append("'\n");
        }
        ocrText.append("\n");

        for (String key : ocrResults.keySet()) {
            if (key.split("/").length == 1) continue;
            String value = ocrResults.get(key);
            if (value != null) Log.d(key, value);
            ocrText.append(key);
            ocrText.append(": '");
            if (value != null) ocrText.append(value); else ocrText.append("---");
            ocrText.append("'\n");
        }

    }
}
